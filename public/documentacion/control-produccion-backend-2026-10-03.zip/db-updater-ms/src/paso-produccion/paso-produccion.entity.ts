import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  In,
} from 'typeorm';
import { OrdenProduccion } from '../orden-produccion/entity';

export enum EstadoPasoOrden {
  PENDIENTE = 'pendiente',
  ACTIVO = 'activo',
  PAUSADO = 'pausado',
  FINALIZADO = 'finalizado',
}

@Entity()
export class PasoProduccion {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  nombre: string;

  @Index()
  @ManyToOne(() => OrdenProduccion, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'ordenId' })
  orden: OrdenProduccion;

  @Column()
  codigoInterno: string;

  @Column('int')
  cantidadRequerida: number;

  @Column('int')
  cantidadProducida: number;

  @Column('int', { default: 0 })
  cantidadPedaleos: number;

  @Column({ type: 'timestamptz', nullable: true })
  fechaMetaAlcanzada: Date | null;

  @Index()
  @Column({ type: 'enum', enum: EstadoPasoOrden, default: EstadoPasoOrden.PENDIENTE })
  estado: EstadoPasoOrden;

  @Column('int')
  numeroPaso: number;
}
