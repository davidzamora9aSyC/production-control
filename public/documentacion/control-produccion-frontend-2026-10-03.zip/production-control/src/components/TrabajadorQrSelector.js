import { useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader } from "@zxing/browser";
import { API_BASE_URL } from "../api";
import { apiFetch } from "../api";

function extractTrabajadorId(text = "") {
  if (!text) return "";
  try {
    const url = new URL(text);
    const fromQuery =
      url.searchParams.get("trabajadorId") ||
      url.searchParams.get("workerId") ||
      url.searchParams.get("id");
    if (fromQuery) return fromQuery;
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts.length) return parts[parts.length - 1];
  } catch {
    // not a URL, ignore
  }
  return text.trim();
}

const onlyDigits = (value = "") => String(value).replace(/\D/g, "");

export default function TrabajadorQrSelector({
  selected,
  onSelect = () => {},
  className = "",
  title = "Trabajador",
  disabled = false,
  disabledMessage = "",
}) {
  const [cameraActive, setCameraActive] = useState(false);
  const [scanMessage, setScanMessage] = useState("");
  const [scanError, setScanError] = useState("");
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState("");
  const [startingCamera, setStartingCamera] = useState(false);
  const [cedula, setCedula] = useState("");
  const videoRef = useRef(null);
  const readerRef = useRef(null);
  const controlsRef = useRef(null);
  const lecturaEnCursoRef = useRef(false);
  const iniciandoCamaraRef = useRef(false);

  const releaseVideoStream = () => {
    const video = videoRef.current;
    if (!video) return;
    const stream = video.srcObject;
    if (stream && typeof stream.getTracks === "function") {
      stream.getTracks().forEach((track) => track.stop());
    }
    video.srcObject = null;
  };

  const stopScanner = async () => {
    if (controlsRef.current && typeof controlsRef.current.stop === "function") {
      try {
        await controlsRef.current.stop();
      } catch (err) {
        console.warn("No se pudo detener el stream de camara", err);
      }
      controlsRef.current = null;
    }
    if (readerRef.current && typeof readerRef.current.reset === "function") {
      try {
        readerRef.current.reset();
      } catch (err) {
        console.warn("No se pudo resetear el lector", err);
      }
    }
    readerRef.current = null;
    releaseVideoStream();
    setCameraActive(false);
    setStartingCamera(false);
    iniciandoCamaraRef.current = false;
  };

  useEffect(() => {
    return () => {
      void stopScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (disabled) {
      void stopScanner();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disabled]);

  const startScanner = async () => {
    if (disabled) return;
    if (cameraActive || iniciandoCamaraRef.current) return;
    iniciandoCamaraRef.current = true;
    setStartingCamera(true);
    setScanError("");
    setScanMessage("");
    setFetchError("");
    try {
      releaseVideoStream();
      readerRef.current = new BrowserMultiFormatReader();
      const reader = readerRef.current;
      lecturaEnCursoRef.current = false;
      controlsRef.current = await reader.decodeFromVideoDevice(
        null,
        videoRef.current,
        (result, err) => {
          if (result) {
            if (lecturaEnCursoRef.current) return;
            lecturaEnCursoRef.current = true;
            const text = result.getText();
            void stopScanner();
            const id = extractTrabajadorId(text);
            setScanMessage(`QR leido: ${text}`);
            setScanError("");
            fetchTrabajador(id);
          } else if (
            err &&
            !lecturaEnCursoRef.current &&
            !err.message?.includes("NotFoundException")
          ) {
            setScanError("Error al leer el codigo. Intenta de nuevo.");
          }
        },
      );
      setCameraActive(true);
    } catch (err) {
      console.warn("No se pudo iniciar la camara", err);
      setScanError(
        'No se pudo acceder a la camara. Autoriza el uso y vuelve a presionar "Escanear QR".',
      );
      await stopScanner();
    } finally {
      iniciandoCamaraRef.current = false;
      setStartingCamera(false);
    }
  };

  const fetchTrabajador = async (id) => {
    if (!id) {
      setFetchError("El QR no contiene un identificador valido.");
      return;
    }
    setLoading(true);
    setFetchError("");
    try {
      const res = await apiFetch(`${API_BASE_URL}/trabajadores/${id}`);
      if (!res.ok) throw new Error("Trabajador no encontrado");
      const data = await res.json();
      onSelect(data);
    } catch (err) {
      onSelect(null);
      setFetchError(
        err?.message || "No se pudo obtener la informacion del trabajador",
      );
    } finally {
      setLoading(false);
    }
  };

  const fetchTrabajadorPorCedula = async () => {
    const target = cedula.trim();
    if (!target) {
      setFetchError("Ingresa la cedula del trabajador.");
      return;
    }
    void stopScanner();
    setLoading(true);
    setFetchError("");
    setScanError("");
    setScanMessage("");
    try {
      const res = await apiFetch(
        `${API_BASE_URL}/trabajadores/buscar?identificacion=${encodeURIComponent(target)}&limit=2`,
      );
      if (!res.ok) throw new Error("No se pudo buscar el trabajador");
      const data = await res.json();
      const targetDigits = onlyDigits(target);
      const matches = Array.isArray(data)
        ? data.filter((item) => {
            const identificacion = String(item.identificacion || "");
            return identificacion === target || onlyDigits(identificacion) === targetDigits;
          })
        : [];
      if (matches.length === 0) {
        throw new Error("No se encontro un trabajador con esa cedula");
      }
      onSelect(matches[0]);
    } catch (err) {
      onSelect(null);
      setFetchError(err?.message || "No se pudo buscar el trabajador");
    } finally {
      setLoading(false);
    }
  };

  const clearSelection = () => {
    if (disabled) return;
    void stopScanner();
    lecturaEnCursoRef.current = false;
    setScanMessage("");
    setScanError("");
    setFetchError("");
    setCedula("");
    onSelect(null);
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <label className="block font-medium">{title}</label>
          <p className="text-xs text-gray-500">
            Escanea el QR del trabajador para continuar.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => {
              if (cameraActive) void stopScanner();
              else void startScanner();
            }}
            disabled={disabled || startingCamera}
            className={`px-3 py-1.5 rounded-full border text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed ${
              disabled ? "cursor-not-allowed" : ""
            }`}
          >
            {cameraActive ? "Detener camara" : startingCamera ? "Abriendo..." : "Escanear QR"}
          </button>
          {selected && (
            <button
              type="button"
              onClick={clearSelection}
              disabled={disabled}
              className="px-3 py-1.5 rounded-full border text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Limpiar
            </button>
          )}
        </div>
      </div>
      {disabled && (
        <p className="text-xs text-yellow-700">
          {disabledMessage || "La busqueda esta bloqueada temporalmente."}
        </p>
      )}
      <div className="border rounded-lg p-3 bg-white space-y-2">
        <label className="block text-sm font-medium">Buscar por cedula</label>
        <div className="flex gap-2">
          <input
            type="text"
            value={cedula}
            onChange={(e) => setCedula(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                fetchTrabajadorPorCedula();
              }
            }}
            disabled={disabled || loading}
            className="flex-1 border rounded-full px-4 py-2 disabled:opacity-50"
            placeholder="Ej: 123456789"
          />
          <button
            type="button"
            onClick={fetchTrabajadorPorCedula}
            disabled={disabled || loading || !cedula.trim()}
            className="px-3 py-1.5 rounded-full border text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Buscar
          </button>
        </div>
      </div>
      <div
        className={`border rounded-lg overflow-hidden bg-black/70 ${disabled ? "opacity-40" : ""}`}
      >
        <video
          ref={videoRef}
          className="w-full h-48 object-cover"
          muted
          playsInline
        />
      </div>
      {scanMessage && <p className="text-xs text-green-600">{scanMessage}</p>}
      {scanError && <p className="text-xs text-red-600">{scanError}</p>}
      {loading && <p className="text-sm text-gray-600">Buscando trabajador...</p>}
      {fetchError && <p className="text-sm text-red-600">{fetchError}</p>}
      {selected && (
        <div className="bg-gray-50 border rounded p-3 text-sm space-y-1">
          <div>
            <strong>Nombre:</strong> {selected.nombre}
          </div>
          <div>
            <strong>Identificacion:</strong> {selected.identificacion ?? "-"}
          </div>
          <div>
            <strong>Grupo:</strong> {selected.grupo ?? "-"}
          </div>
          <div>
            <strong>Turno:</strong> {selected.turno ?? "-"}
          </div>
          <div>
            <strong>Estado:</strong> {selected.estado ?? "-"}
          </div>
        </div>
      )}
    </div>
  );
}
