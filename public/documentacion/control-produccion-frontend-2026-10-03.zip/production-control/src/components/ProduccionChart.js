import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useState, useEffect, useMemo, useContext } from "react";
import { ExpandButton, ExpandContext } from "./ExpandableCard";
import { useAreas } from "../context/AreasContext";
import { fetchJsonCached, API_BASE_URL } from "../api";

export default function ProduccionChart() {
    const [proceso, setProceso] = useState("");
    const [periodo, setPeriodo] = useState("Meses");
    const [rango, setRango] = useState("Ultimos 12 meses");
    const [raw, setRaw] = useState([]);
    const [loading, setLoading] = useState(false);
    const { expanded } = useContext(ExpandContext);
    const { areas } = useAreas();

    useEffect(() => {
        if (proceso && !areas.some(x => String(x.id) === String(proceso))) {
            // Mantener el comportamiento anterior: si el área ya no existe, tomar la primera o vaciar
            setProceso(areas[0]?.id || "");
        }
    }, [areas, proceso]);

    useEffect(() => {
        if (periodo === "Meses" && (rango !== "Ultimos 12 meses" && rango !== "Año actual")) setRango("Ultimos 12 meses");
        if (periodo === "Días" && (rango !== "Ultimos 30 días" && rango !== "Mes actual")) setRango("Ultimos 30 días");
    }, [periodo, rango]);

    const endpoint = useMemo(() => {
        if (periodo === "Meses") return rango === "Año actual" ? "/produccion/mensual/ano-actual" : "/produccion/mensual/ultimos-12-meses";
        return rango === "Mes actual" ? "/produccion/diaria/mes-actual" : "/produccion/diaria/ultimos-30-dias";
    }, [periodo, rango]);

    useEffect(() => {
        const load = async () => {
            setLoading(true);
            try {
                const url = proceso ? `${API_BASE_URL}${endpoint}?areaId=${encodeURIComponent(proceso)}` : `${API_BASE_URL}${endpoint}`;
                const json = await fetchJsonCached(url, {}, { ttlMs: 15000 });
                setRaw(Array.isArray(json) ? json : []);
            } catch (e) {
                setRaw([]);
            } finally {
                setLoading(false);
            }
        };
        if (proceso === undefined) return;
        load();
    }, [endpoint, proceso]);

    const data = useMemo(() => {
        const dataMap = {};

        raw.forEach(r => {
            const d = new Date(periodo === "Meses" ? r.mes : r.fecha);
            const label = periodo === "Meses"
                ? `${["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"][d.getUTCMonth()]} ${d.getUTCFullYear()}`
                : `${d.getUTCDate().toString().padStart(2,"0")}/${(d.getUTCMonth()+1).toString().padStart(2,"0")}`;

            if (!dataMap[label]) {
                dataMap[label] = 0;
            }

            dataMap[label] += Number(r.piezas) || 0;
        });

        return Object.entries(dataMap).map(([name, value]) => ({ name, value }));
    }, [raw, periodo]);

    const isDiario = periodo === "Días";
    const tickStep = useMemo(() => isDiario ? Math.max(1, Math.ceil(data.length / 6)) : 1, [isDiario, data.length]);

    const opcionesRango = periodo === "Meses"
        ? ["Ultimos 12 meses", "Año actual"]
        : ["Ultimos 30 días", "Mes actual"];

    return (
        <div className={`w-full ${expanded ? "h-full flex flex-col" : "max-h-[40%] mb-16"}`}>
            <div className="flex justify-between items-center mb-6 ">
                <div>
                    <span className="font-semibold text-2xl mr-4 ">Producción por</span>
                    <select value={proceso} onChange={e => setProceso(e.target.value)} className="border-b border-black focus:outline-none">
                        <option value="">Todos</option>
                        {areas.map(a => (
                            <option key={a.id} value={a.id}>{a.nombre}</option>
                        ))}
                    </select>
                </div>

                <div className="flex items-center gap-3">
                    <select value={periodo} onChange={e => setPeriodo(e.target.value)} className="bg-gray-200 px-4 py-1 rounded-full text-md">
                        <option>Meses</option>
                        <option>Días</option>
                    </select>
                    <select value={rango} onChange={e => setRango(e.target.value)} className="bg-gray-200 px-4 py-1 rounded-full text-md">
                        {opcionesRango.map(op => (
                            <option key={op}>{op}</option>
                        ))}
                    </select>
                    <ExpandButton />
                </div>
            </div>

            <div className={`border rounded-2xl shadow-md pl-1 pr-5 pb-4 pt-6 ${expanded ? "flex-1 min-h-0" : ""}`}>
                <ResponsiveContainer width="100%" height={expanded ? "100%" : 223}>
                    <LineChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" />
                        {isDiario ? (
                          <XAxis dataKey="name" interval={0} tickMargin={8} tickFormatter={(v, i) => (i % tickStep === 0) ? v : ""} />
                        ) : (
                          <XAxis dataKey="name" />
                        )}
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} dot />
                    </LineChart>
                </ResponsiveContainer>
                {loading && <div className="px-4 py-2 text-sm">Cargando…</div>}
            </div>
        </div>
    );
}
