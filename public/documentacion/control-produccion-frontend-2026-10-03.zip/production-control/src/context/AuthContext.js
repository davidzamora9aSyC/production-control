import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import { API_BASE_URL } from "../api";
import { apiFetch } from "../api";

const TOKEN_KEY = "auth:token";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  const validateToken = useCallback(async (tkn) => {
    try {
      const res = await apiFetch(`${API_BASE_URL}/auth/validate`, {
        method: "GET",
        headers: { Authorization: `Bearer ${tkn}` },
      });
      if (!res.ok) return false;
      const data = await res.json().catch(() => ({}));
      return !!data?.valid;
    } catch {
      return false;
    }
  }, []);

  // Bootstrap: carga token y valida con backend
  useEffect(() => {
    const init = async () => {
      try {
        const stored = localStorage.getItem(TOKEN_KEY);
        if (stored) {
          setToken(stored);
          const ok = await validateToken(stored);
          setIsAuthenticated(ok);
        } else {
          setIsAuthenticated(false);
        }
      } catch {
        setIsAuthenticated(false);
      } finally {
        setIsChecking(false);
      }
    };
    init();
  }, [validateToken]);

  const login = useCallback(async (username, password) => {
    const res = await apiFetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      let msg = "Credenciales inválidas";
      try { const j = await res.json(); if (j?.message) msg = j.message; } catch {}
      throw new Error(msg);
    }
    const data = await res.json();
    const accessToken = data?.access_token || data?.accessToken;
    if (!accessToken) throw new Error("Respuesta de login sin token");
    localStorage.setItem(TOKEN_KEY, accessToken);
    setToken(accessToken);
    setIsAuthenticated(true);
    return true;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setIsAuthenticated(false);
  }, []);

  const revalidate = useCallback(async () => {
    setIsChecking(true);
    const ok = token ? await validateToken(token) : false;
    setIsAuthenticated(ok);
    setIsChecking(false);
    return ok;
  }, [token, validateToken]);

  const value = useMemo(
    () => ({ token, isAuthenticated, isChecking, login, logout, revalidate }),
    [token, isAuthenticated, isChecking, login, logout, revalidate]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth debe usarse dentro de AuthProvider");
  return ctx;
}